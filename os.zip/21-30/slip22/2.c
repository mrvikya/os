#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100

int disk[MAX_BLOCKS];
int n;

// Function to display the Bit Vector
void showBitVector() {
    printf("Bit Vector: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }
    printf("\n");
}

// Function to display the Directory (Allocated blocks)
void showDirectory() {
    printf("Directory (Allocated blocks): ");
    for (int i = 0; i < n; i++) {
        if (disk[i] == 1) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

// Function to delete a file by clearing its allocated blocks
void deleteFile(int start, int length) {
    int i;
    for (i = start; i < start + length && i < n; i++) {
        if (disk[i] == 1) {
            disk[i] = 0;
        }
    }
    printf("File deleted from blocks %d to %d\n", start, i - 1);
}

int main() {
    int option, start, length;

    // Get the total number of disk blocks
    printf("Enter the total number of disk blocks: ");
    scanf("%d", &n);

    // Initialize disk with random allocation (0 = free, 1 = allocated)
    for (int i = 0; i < n; i++) {
        disk[i] = rand() % 2;
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Show Bit Vector\n");
        printf("2. Show Directory\n");
        printf("3. Delete File\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                showBitVector();
                break;
            case 2:
                showDirectory();
                break;
            case 3:
                printf("Enter the starting block and length of the file to delete: ");
                scanf("%d %d", &start, &length);
                deleteFile(start, length);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}


/*
Enter the total number of disk blocks: 10

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 1
Bit Vector: 1 0 1 1 0 1 0 0 1 1

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 2
Directory (Allocated blocks): 0 2 3 5 8 9

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 3
Enter the starting block and length of the file to delete: 3 2
File deleted from blocks 3 to 4

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 1
Bit Vector: 1 0 1 0 0 1 0 0 1 1

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 2
Directory (Allocated blocks): 0 2 5 8 9

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete File
4. Exit
Enter your choice: 4

*/