#include <stdio.h>
#include <stdlib.h>

// Function to display a matrix
void displayMatrix(int matrix[][10], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

// Function to calculate the Need matrix
void calculateNeedMatrix(int allocation[][10], int max[][10], int need[][10], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to check if a request can be granted
int canGrantRequest(int request[], int available[], int need[], int n) {
    for (int i = 0; i < n; i++) {
        if (request[i] > need[i]) {
            return 0; // Request exceeds need
        }
        if (request[i] > available[i]) {
            return 0; // Request exceeds available resources
        }
    }
    return 1;
}

int main() {
    int m, n;

    // Get user input for number of processes and resources
    printf("Enter the number of processes: ");
    scanf("%d", &m);
    printf("Enter the number of resource types: ");
    scanf("%d", &n);

    int allocation[m][n], max[m][n], available[n], need[m][n], request[n];

    // Get user input for Allocation Matrix
    printf("Enter the Allocation Matrix:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &allocation[i][j]);
        }
    }

    // Get user input for Maximum Matrix
    printf("Enter the Maximum Matrix:\n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &max[i][j]);
        }
    }

    // Get user input for Available Resources
    printf("Enter the Available resources:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &available[i]);
    }

    // Calculate Need Matrix
    calculateNeedMatrix(allocation, max, need, m, n);

    // Display Need Matrix
    printf("\nNeed Matrix:\n");
    displayMatrix(need, m, n);

    // Get user input for resource request
    printf("Enter the request from process: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &request[i]);
    }

    // Check if request can be granted
    if (canGrantRequest(request, available, need[0], n)) {
        printf("The request can be granted immediately.\n");
    } else {
        printf("The request cannot be granted immediately.\n");
    }

    return 0;
}


/*
Enter the number of processes: 3
Enter the number of resource types: 3
Enter the Allocation Matrix:
0 1 0
2 0 0
3 0 3
Enter the Maximum Matrix:
7 5 3
3 2 2
9 0 2
Enter the Available resources:
3 3 2

*/