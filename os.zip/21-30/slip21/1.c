#include <stdio.h>
#include <stdlib.h>

// Function to implement FCFS Disk Scheduling
void fcfs(int requests[], int n, int head) {
    int total_head_movements = 0;

    printf("Disk Requests Order: ");
    for (int i = 0; i < n; i++) {
        total_head_movements += abs(head - requests[i]);
        head = requests[i];
        printf("%d ", head);
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", total_head_movements);
}

int main() {
    int requests[] = {55, 58, 39, 18, 90, 160, 150, 38, 184};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head;

    // Get user input for starting head position
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Call FCFS function
    fcfs(requests, n, head);

    return 0;
}
