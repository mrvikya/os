#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size, n = 1000;
    int numbers[n], local_sum = 0, global_sum = 0;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Root process generates random numbers
    if (rank == 0) {
        for (int i = 0; i < n; i++) {
            numbers[i] = rand() % 1000;
        }
    }

    // Broadcast numbers array to all processes
    MPI_Bcast(numbers, n, MPI_INT, 0, MPI_COMM_WORLD);

    // Each process calculates sum of even numbers in its portion
    for (int i = rank; i < n; i += size) {
        if (numbers[i] % 2 == 0) {
            local_sum += numbers[i];
        }
    }

    // Reduce local sums to compute the global sum at root process
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Root process prints the final sum of even numbers
    if (rank == 0) {
        printf("Sum of all even numbers: %d\n", global_sum);
    }

    // Finalize MPI environment
    MPI_Finalize();
    
    return 0;
}
