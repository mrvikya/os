#include <stdio.h>
#include <stdbool.h>

#define P 5  // Number of processes
#define R 3  // Number of resource types

// Allocation Matrix
int allocation[P][R] = {
    {0, 1, 0},
    {2, 0, 0},
    {3, 0, 3},
    {2, 1, 1},
    {0, 0, 2}
};

// Maximum Requirement Matrix
int max[P][R] = {
    {0, 0, 0},
    {2, 0, 2},
    {0, 0, 0},
    {1, 0, 0},
    {0, 0, 2}
};

// Available resources
int available[R] = {0, 0, 0};  // Given in the problem
int need[P][R];  // Need Matrix

// Function to calculate the Need matrix
void calculateNeedMatrix() {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to display a matrix
void displayMatrix(int matrix[P][R], char *title) {
    printf("\n%s:\n", title);
    printf("Process\tA B C\n");
    for (int i = 0; i < P; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < R; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

// Function to check if the system is in a safe state
bool isSafeState() {
    int work[R];
    bool finish[P] = {false};
    int safeSequence[P], count = 0;

    // Initialize work with available resources
    for (int i = 0; i < R; i++) {
        work[i] = available[i];
    }

    while (count < P) {
        bool found = false;
        for (int i = 0; i < P; i++) {
            if (!finish[i]) {
                int j;
                for (j = 0; j < R; j++) {
                    if (need[i][j] > work[j]) {
                        break;
                    }
                }
                if (j == R) {  // If all needs can be satisfied
                    for (int k = 0; k < R; k++) {
                        work[k] += allocation[i][k];
                    }
                    safeSequence[count++] = i;
                    finish[i] = true;
                    found = true;
                }
            }
        }
        if (!found) {
            return false;
        }
    }

    // Display Safe Sequence
    printf("\nSystem is in a safe state.\nSafe Sequence: ");
    for (int i = 0; i < P; i++) {
        printf("P%d ", safeSequence[i]);
    }
    printf("\n");

    return true;
}

int main() {
    int choice;

    // Calculate Need Matrix
    calculateNeedMatrix();

    while (1) {
        printf("\nMenu:\n");
        printf("1. Display Need Matrix\n");
        printf("2. Check System Safety\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                displayMatrix(need, "Need Matrix");
                break;
            case 2:
                if (!isSafeState()) {
                    printf("\nSystem is NOT in a safe state. Deadlock may occur!\n");
                }
                break;
            case 3:
                return 0;
            default:
                printf("Invalid choice, please try again.\n");
        }
    }

    return 0;
}


/*
Menu:
1. Display Need Matrix
2. Check System Safety
3. Exit
Enter your choice: 1

Need Matrix:
Process  A B C
P0       0 -1 0
P1       0  0 2
P2      -3  0 -3
P3      -1 -1 -1
P4       0  0 0

Menu:
1. Display Need Matrix
2. Check System Safety
3. Exit
Enter your choice: 2

System is NOT in a safe state. Deadlock may occur!
*/