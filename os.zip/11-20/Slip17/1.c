#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100  // Maximum disk blocks

int disk[MAX_BLOCKS];  // Bit vector to track allocated/free blocks
int indexTable[MAX_BLOCKS];  // Index table for files
int n;  // Total number of disk blocks

// Function to show the Bit Vector
void showBitVector() {
    printf("Bit Vector (0 = Free, 1 = Allocated):\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }
    printf("\n");
}

// Function to show the directory (files and their allocated blocks)
void showDirectory() {
    printf("Directory (Index Blocks and Allocated Blocks):\n");
    for (int i = 0; i < n; i++) {
        if (indexTable[i] != -1) {
            printf("File at Index %d -> Block %d\n", i, indexTable[i]);
        }
    }
}

// Function to delete a file by freeing its allocated blocks
void deleteFile(int indexBlock) {
    if (indexBlock < 0 || indexBlock >= n || indexTable[indexBlock] == -1) {
        printf("File not found at index block %d.\n", indexBlock);
        return;
    }

    // Free the allocated block
    disk[indexTable[indexBlock]] = 0;
    indexTable[indexBlock] = -1;

    printf("File at index block %d deleted successfully.\n", indexBlock);
}

int main() {
    int option, indexBlock;

    // Get total number of disk blocks
    printf("Enter the total number of disk blocks: ");
    scanf("%d", &n);

    // Initialize disk (randomly allocate some blocks)
    for (int i = 0; i < n; i++) {
        disk[i] = rand() % 2;  // 0 = free, 1 = allocated
        indexTable[i] = (disk[i] == 1) ? i : -1;  // Assign index only if allocated
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Show Bit Vector\n");
        printf("2. Show Directory\n");
        printf("3. Delete Already File\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                showBitVector();
                break;
            case 2:
                showDirectory();
                break;
            case 3:
                printf("Enter the index block of the file to delete: ");
                scanf("%d", &indexBlock);
                deleteFile(indexBlock);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}


/*
Enter the total number of disk blocks: 10

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete Already File
4. Exit
Enter your choice: 1

Bit Vector (0 = Free, 1 = Allocated):
1 0 1 1 0 1 0 0 1 1 

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete Already File
4. Exit
Enter your choice: 2

Directory (Index Blocks and Allocated Blocks):
File at Index 0 -> Block 0
File at Index 2 -> Block 2
File at Index 3 -> Block 3
File at Index 5 -> Block 5
File at Index 8 -> Block 8
File at Index 9 -> Block 9

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete Already File
4. Exit
Enter your choice: 3
Enter the index block of the file to delete: 3
File at index block 3 deleted successfully.

Menu:
1. Show Bit Vector
2. Show Directory
3. Delete Already File
4. Exit
Enter your choice: 1

Bit Vector (0 = Free, 1 = Allocated):
1 0 1 0 0 1 0 0 1 1 

*/