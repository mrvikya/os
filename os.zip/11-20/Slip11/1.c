#include <stdio.h>

#define P 5  // Number of processes
#define R 3  // Number of resource types

// Matrices for Allocation, Max, and Need
int allocation[P][R] = {
    {0, 1, 0},
    {2, 0, 0},
    {3, 0, 3},
    {2, 1, 1},
    {0, 0, 2}
};

int max[P][R] = {
    {0, 0, 0},
    {2, 0, 2},
    {0, 0, 0},
    {1, 0, 0},
    {0, 0, 2}
};

int available[R];  // Available resources
int need[P][R];    // Need matrix

// Function to calculate the Need matrix
void calculateNeedMatrix() {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to display the Allocation and Max matrices
void displayAllocationMax() {
    printf("\nProcess\tAllocation\tMax\n");
    printf("\tA B C\t\tA B C\n");
    for (int i = 0; i < P; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < R; j++) {
            printf("%d ", allocation[i][j]);
        }
        printf("\t\t");
        for (int j = 0; j < R; j++) {
            printf("%d ", max[i][j]);
        }
        printf("\n");
    }
}

// Function to display the Need matrix
void displayNeedMatrix() {
    printf("\nProcess\tNeed\n");
    printf("\tA B C\n");
    for (int i = 0; i < P; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < R; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
}

// Function to display Available resources
void displayAvailable() {
    printf("\nAvailable Resources: ");
    for (int i = 0; i < R; i++) {
        printf("%d ", available[i]);
    }
    printf("\n");
}

// Function to accept available resources from user
void acceptAvailable() {
    printf("Enter available resources (A B C): ");
    for (int i = 0; i < R; i++) {
        scanf("%d", &available[i]);
    }
}

int main() {
    int choice;

    // Calculate Need Matrix before displaying it
    calculateNeedMatrix();

    while (1) {
        printf("\nMenu:\n");
        printf("1. Accept Available\n");
        printf("2. Display Allocation and Max\n");
        printf("3. Display Need Matrix\n");
        printf("4. Display Available\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                acceptAvailable();
                break;
            case 2:
                displayAllocationMax();
                break;
            case 3:
                displayNeedMatrix();
                break;
            case 4:
                displayAvailable();
                break;
            case 5:
                return 0;
            default:
                printf("Invalid choice, please try again.\n");
        }
    }

    return 0;
}
