#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define SIZE 1000  // Total number of elements

int main(int argc, char *argv[]) {
    int rank, size;
    int numbers[SIZE], local_min, global_min;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Generate random numbers on the root process
    if (rank == 0) {
        for (int i = 0; i < SIZE; i++) {
            numbers[i] = rand() % 1000;  // Random numbers between 0 and 999
        }
    }

    // Determine chunk size for each process
    int chunk_size = SIZE / size;
    int local_numbers[chunk_size];

    // Distribute the data among all processes
    MPI_Scatter(numbers, chunk_size, MPI_INT, local_numbers, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Find local minimum in each process
    local_min = local_numbers[0];
    for (int i = 1; i < chunk_size; i++) {
        if (local_numbers[i] < local_min) {
            local_min = local_numbers[i];
        }
    }

    // Reduce all local minimums to find the global minimum at root process
    MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

    // Print the minimum number on the root process
    if (rank == 0) {
        printf("The minimum value is: %d\n", global_min);
    }

    // Finalize MPI environment
    MPI_Finalize();
    
    return 0;
}
