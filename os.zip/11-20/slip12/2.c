#include <stdio.h>
#include <stdlib.h>

// Function to sort disk requests in ascending order
void sortRequests(int requests[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (requests[i] > requests[j]) {
                temp = requests[i];
                requests[i] = requests[j];
                requests[j] = temp;
            }
        }
    }
}

// Function to implement C-LOOK Disk Scheduling
void clook(int requests[], int n, int head, int direction) {
    int total_head_movements = 0;
    sortRequests(requests, n);

    printf("\nOrder of requests served:\n");

    if (direction == 1) { // Moving right first
        for (int i = 0; i < n; i++) {
            if (requests[i] >= head) {
                printf("%d ", requests[i]);
                total_head_movements += abs(head - requests[i]);
                head = requests[i];
            }
        }
        for (int i = 0; i < n; i++) {
            if (requests[i] < head) {
                printf("%d ", requests[i]);
                total_head_movements += abs(head - requests[i]);
                head = requests[i];
            }
        }
    } else { // Moving left first
        for (int i = n - 1; i >= 0; i--) {
            if (requests[i] <= head) {
                printf("%d ", requests[i]);
                total_head_movements += abs(head - requests[i]);
                head = requests[i];
            }
        }
        for (int i = n - 1; i >= 0; i--) {
            if (requests[i] > head) {
                printf("%d ", requests[i]);
                total_head_movements += abs(head - requests[i]);
                head = requests[i];
            }
        }
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", total_head_movements);
}

int main() {
    int requests[] = {23, 89, 132, 42, 187, 69, 36, 55};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head, direction;

    // Get user input for starting head position
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Get direction (1 for right, 0 for left)
    printf("Enter the direction (1 for right, 0 for left): ");
    scanf("%d", &direction);

    // Call C-LOOK function
    clook(requests, n, head, direction);

    return 0;
}
