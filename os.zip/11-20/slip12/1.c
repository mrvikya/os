#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define SIZE 1000  // Total number of elements

int main(int argc, char *argv[]) {
    int rank, size;
    int numbers[SIZE], local_sum = 0, total_sum = 0;
    float average;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Generate random numbers on the root process
    if (rank == 0) {
        for (int i = 0; i < SIZE; i++) {
            numbers[i] = rand() % 1000; // Random numbers between 0 and 999
        }
    }

    // Determine chunk size for each process
    int chunk_size = SIZE / size;
    int local_numbers[chunk_size];

    // Distribute the data among all processes
    MPI_Scatter(numbers, chunk_size, MPI_INT, local_numbers, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Calculate local sum
    for (int i = 0; i < chunk_size; i++) {
        local_sum += local_numbers[i];
    }

    // Reduce local sums to compute the total sum at root process
    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Calculate and print average on the root process
    if (rank == 0) {
        average = (float)total_sum / SIZE;
        printf("Total Sum: %d\n", total_sum);
        printf("Average: %.2f\n", average);
    }

    // Finalize MPI environment
    MPI_Finalize();
    
    return 0;
}
