#include <stdio.h>
#include <stdbool.h>

#define P 5  // Number of processes
#define R 3  // Number of resource types

// Matrices for Allocation, Max, and Need
int allocation[P][R] = {
    {0, 1, 0},
    {2, 0, 0},
    {3, 0, 3},
    {2, 1, 1},
    {0, 0, 2}
};

int max[P][R] = {
    {0, 0, 0},
    {2, 0, 2},
    {0, 0, 0},
    {1, 0, 0},
    {0, 0, 2}
};

int available[R] = {0, 0, 0};  // Available resources
int need[P][R];  // Need matrix

// Function to calculate the Need matrix
void calculateNeedMatrix() {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to display the Need matrix
void displayNeedMatrix() {
    printf("\nNeed Matrix:\n");
    printf("Process\tA B C\n");
    for (int i = 0; i < P; i++) {
        printf("P%d\t", i);
        for (int j = 0; j < R; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }
}

// Function to check if the system is in a safe state
bool isSafeState() {
    int work[R];
    bool finish[P] = {false};
    int safeSequence[P], count = 0;

    // Initialize work with available resources
    for (int i = 0; i < R; i++) {
        work[i] = available[i];
    }

    while (count < P) {
        bool found = false;
        for (int i = 0; i < P; i++) {
            if (!finish[i]) {
                int j;
                for (j = 0; j < R; j++) {
                    if (need[i][j] > work[j]) {
                        break;
                    }
                }
                if (j == R) {
                    for (int k = 0; k < R; k++) {
                        work[k] += allocation[i][k];
                    }
                    safeSequence[count++] = i;
                    finish[i] = true;
                    found = true;
                }
            }
        }
        if (!found) {
            return false;
        }
    }

    // Display Safe Sequence
    printf("\nSystem is in a safe state.\nSafe Sequence: ");
    for (int i = 0; i < P; i++) {
        printf("P%d ", safeSequence[i]);
    }
    printf("\n");

    return true;
}

int main() {
    int choice;

    // Calculate Need Matrix
    calculateNeedMatrix();

    while (1) {
        printf("\nMenu:\n");
        printf("1. Display Need Matrix\n");
        printf("2. Check System Safety\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                displayNeedMatrix();
                break;
            case 2:
                if (!isSafeState()) {
                    printf("\nSystem is NOT in a safe state. Deadlock may occur!\n");
                }
                break;
            case 3:
                return 0;
            default:
                printf("Invalid choice, please try again.\n");
        }
    }

    return 0;
}
