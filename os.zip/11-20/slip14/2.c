#include <stdio.h>
#include <stdlib.h>

// Function to swap two integers
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to find the closest request to the current head position
int findClosestRequest(int requests[], int n, int head) {
    int min_dist = 99999, index = -1;
    for (int i = 0; i < n; i++) {
        if (requests[i] != -1) {  // Ignore already served requests
            int dist = abs(requests[i] - head);
            if (dist < min_dist) {
                min_dist = dist;
                index = i;
            }
        }
    }
    return index;
}

// Function to implement SSTF Disk Scheduling
void sstf(int requests[], int n, int head) {
    int total_head_movements = 0;
    
    printf("Disk Requests Order: ");
    for (int i = 0; i < n; i++) {
        int index = findClosestRequest(requests, n, head);
        total_head_movements += abs(head - requests[index]);
        head = requests[index];
        requests[index] = -1; // Mark the request as served
        printf("%d ", head);
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", total_head_movements);
}

int main() {
    int requests[] = {55, 58, 39, 18, 90, 160, 150, 38, 184};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head;

    // Get user input for starting head position
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Call SSTF function
    sstf(requests, n, head);

    return 0;
}
