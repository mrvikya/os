#include <stdio.h>
#include <stdlib.h>

// Function to sort disk requests in ascending order
void sortRequests(int requests[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (requests[i] > requests[j]) {
                temp = requests[i];
                requests[i] = requests[j];
                requests[j] = temp;
            }
        }
    }
}

// Function to implement LOOK Disk Scheduling
void look(int requests[], int n, int head, char direction) {
    int totalHeadMovements = 0;
    int left[100], right[100];
    int leftCount = 0, rightCount = 0;

    // Separate requests into left and right of the head
    for (int i = 0; i < n; i++) {
        if (requests[i] < head) {
            left[leftCount++] = requests[i];
        } else {
            right[rightCount++] = requests[i];
        }
    }

    // Sort left and right requests in ascending order
    sortRequests(left, leftCount);
    sortRequests(right, rightCount);

    printf("\nRequests in the order they are served:\n");

    if (direction == 'L') {  // Moving left first
        // Serve requests to the left of head
        for (int i = leftCount - 1; i >= 0; i--) {
            printf("%d ", left[i]);
            totalHeadMovements += abs(head - left[i]);
            head = left[i];
        }

        // Serve requests from right after reaching the last left request
        for (int i = 0; i < rightCount; i++) {
            printf("%d ", right[i]);
            totalHeadMovements += abs(head - right[i]);
            head = right[i];
        }
    } else if (direction == 'R') {  // Moving right first
        // Serve requests to the right of head
        for (int i = 0; i < rightCount; i++) {
            printf("%d ", right[i]);
            totalHeadMovements += abs(head - right[i]);
            head = right[i];
        }

        // Serve requests from left after reaching the last right request
        for (int i = leftCount - 1; i >= 0; i--) {
            printf("%d ", left[i]);
            totalHeadMovements += abs(head - left[i]);
            head = left[i];
        }
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", totalHeadMovements);
}

int main() {
    int requests[] = {176, 79, 34, 60, 92, 11, 41, 114};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head;
    char direction;

    // Get user input for starting head position
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Get direction (L for Left, R for Right)
    printf("Enter the direction (L for Left, R for Right): ");
    scanf(" %c", &direction);

    // Call LOOK function
    look(requests, n, head, direction);

    return 0;
}
