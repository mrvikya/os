#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100

int n; // Number of blocks
int bitVector[MAX_BLOCKS]; // Bit vector for allocation
int directory[MAX_BLOCKS]; // Directory to store file block allocations

// Function to display the Bit Vector
void showBitVector() {
    printf("Bit Vector (0=Free, 1=Allocated):\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", bitVector[i]);
    }
    printf("\n");
}

// Function to create a new file and allocate blocks
void createNewFile() {
    int fileSize;
    
    printf("Enter the size of the new file (number of blocks): ");
    scanf("%d", &fileSize);

    int allocatedBlocks = 0;
    int fileBlocks[fileSize];

    // Allocate free blocks
    for (int i = 0; i < n && allocatedBlocks < fileSize; i++) {
        if (bitVector[i] == 0) { // Free block found
            bitVector[i] = 1;
            fileBlocks[allocatedBlocks] = i;
            allocatedBlocks++;
        }
    }

    if (allocatedBlocks == fileSize) {
        printf("File created successfully with blocks: ");
        for (int i = 0; i < fileSize; i++) {
            printf("%d ", fileBlocks[i]);
        }
        printf("\n");
    } else {
        printf("Not enough free blocks to create the file.\n");
    }
}

// Function to display the Directory (allocated blocks)
void showDirectory() {
    printf("Directory (File Allocations):\n");
    for (int i = 0; i < n; i++) {
        if (bitVector[i] == 1) {
            printf("Block %d allocated\n", i);
        }
    }
}

int main() {
    int choice;

    // Get total number of blocks
    printf("Enter the total number of blocks: ");
    scanf("%d", &n);

    // Initialize bit vector and directory
    for (int i = 0; i < n; i++) {
        bitVector[i] = 0;  // 0 means free block
        directory[i] = -1; // No file allocated yet
    }

    do {
        printf("\nMenu:\n");
        printf("1. Show Bit Vector\n");
        printf("2. Create New File\n");
        printf("3. Show Directory\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                showBitVector();
                break;
            case 2:
                createNewFile();
                break;
            case 3:
                showDirectory();
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);

    return 0;
}
