#include <stdio.h>
#include <stdlib.h>

#define MAX_BLOCKS 100

int n;  // Number of blocks in the disk
int bitVector[MAX_BLOCKS];  // Bit vector to track allocated/free blocks
int directory[MAX_BLOCKS];   // Directory to store file block allocations

// Function to display the Bit Vector
void showBitVector() {
    printf("Bit Vector: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", bitVector[i]);
    }
    printf("\n");
}

// Function to allocate a new file using contiguous allocation
void createNewFile(int fileSize) {
    int start = -1;

    // Search for contiguous free blocks
    for (int i = 0; i <= n - fileSize; i++) {
        int found = 1;
        for (int j = i; j < i + fileSize; j++) {
            if (bitVector[j] == 1) {  // Block is already allocated
                found = 0;
                break;
            }
        }
        if (found) {
            start = i;
            break;
        }
    }

    // If no contiguous space found, return
    if (start == -1) {
        printf("Not enough space to allocate the file.\n");
        return;
    }

    // Mark blocks as allocated
    for (int i = start; i < start + fileSize; i++) {
        bitVector[i] = 1;
        directory[i] = 1;
    }

    printf("File allocated starting from block %d.\n", start);
}

// Function to display the Directory
void showDirectory() {
    printf("Directory: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", directory[i]);
    }
    printf("\n");
}

int main() {
    int choice, fileSize;

    // Get total number of disk blocks
    printf("Enter the number of blocks in the disk: ");
    scanf("%d", &n);

    // Initialize bit vector and directory
    for (int i = 0; i < n; i++) {
        bitVector[i] = 0;  // 0 means free block
        directory[i] = 0;  // No file allocated yet
    }

    while (1) {
        printf("\nMenu:\n");
        printf("1. Show Bit Vector\n");
        printf("2. Create New File\n");
        printf("3. Show Directory\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                showBitVector();
                break;
            case 2:
                printf("Enter the size of the file to create: ");
                scanf("%d", &fileSize);
                createNewFile(fileSize);
                break;
            case 3:
                showDirectory();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
