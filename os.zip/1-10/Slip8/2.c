#include <stdio.h>
#include <stdlib.h>
#include <string.h>  // For memset()

// Function to implement SSTF Disk Scheduling
void sstf(int requests[], int n, int head) {
    int totalHeadMovements = 0;
    int served[n];

    // Initialize the served array to track completed requests
    memset(served, 0, sizeof(served));

    printf("Request order: ");

    for (int i = 0; i < n; i++) {
        int minDist = -1;
        int index = -1;

        // Find the closest request to the current head position
        for (int j = 0; j < n; j++) {
            if (!served[j]) {  // If request is not yet served
                int dist = abs(requests[j] - head);
                if (minDist == -1 || dist < minDist) {
                    minDist = dist;
                    index = j;
                }
            }
        }

        // Mark the request as served
        served[index] = 1;
        totalHeadMovements += minDist;
        head = requests[index];

        printf("%d ", requests[index]);
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", totalHeadMovements);
}

int main() {
    int requests[] = {186, 89, 44, 70, 102, 22, 51, 124};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head;

    // Get starting head position from the user
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Call SSTF function
    sstf(requests, n, head);

    return 0;
}
