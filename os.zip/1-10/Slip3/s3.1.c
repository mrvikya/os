#include <stdio.h>

#define PROCESS_COUNT 5
#define RESOURCE_COUNT 4

// Allocation Matrix
int allocation[PROCESS_COUNT][RESOURCE_COUNT] = {
    {0, 0, 1, 2},
    {1, 0, 0, 0},
    {1, 3, 5, 4},
    {0, 6, 3, 2},
    {0, 0, 1, 4}
};

// Maximum Need Matrix
int max[PROCESS_COUNT][RESOURCE_COUNT] = {
    {0, 0, 1, 2},
    {1, 7, 5, 0},
    {2, 3, 5, 6},
    {0, 6, 5, 2},
    {0, 6, 5, 6}
};

// Available Resources
int available[RESOURCE_COUNT] = {1, 5, 2, 0};

// Need Matrix
int need[PROCESS_COUNT][RESOURCE_COUNT];

// Function to calculate the Need Matrix
void calculateNeedMatrix() {
    for (int i = 0; i < PROCESS_COUNT; i++) {
        for (int j = 0; j < RESOURCE_COUNT; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to check if the system is in a safe state
int isSafeState() {
    int work[RESOURCE_COUNT];
    int finish[PROCESS_COUNT] = {0};
    int safeSequence[PROCESS_COUNT];
    int count = 0;

    // Initialize work array with available resources
    for (int i = 0; i < RESOURCE_COUNT; i++) {
        work[i] = available[i];
    }

    while (count < PROCESS_COUNT) {
        int found = 0;

        for (int i = 0; i < PROCESS_COUNT; i++) {
            if (finish[i] == 0) {
                int j;
                for (j = 0; j < RESOURCE_COUNT; j++) {
                    if (need[i][j] > work[j])
                        break;
                }

                // If need[i] <= work, allocate resources to process i
                if (j == RESOURCE_COUNT) {
                    for (int k = 0; k < RESOURCE_COUNT; k++) {
                        work[k] += allocation[i][k];
                    }

                    safeSequence[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }

        // If no process is found, the system is in an unsafe state
        if (!found) {
            printf("System is not in a safe state.\n");
            return 0;
        }
    }

    // If all processes are finished, print the safe sequence
    printf("System is in a safe state.\nSafe sequence is: ");
    for (int i = 0; i < PROCESS_COUNT; i++) {
        printf("P%d ", safeSequence[i]);
    }
    printf("\n");
    return 1;
}

int main() {
    // Calculate Need Matrix
    calculateNeedMatrix();

    // Display Need Matrix
    printf("Need Matrix:\n");
    for (int i = 0; i < PROCESS_COUNT; i++) {
        for (int j = 0; j < RESOURCE_COUNT; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }

    // Check if system is in a safe state
    isSafeState();

    return 0;
}
