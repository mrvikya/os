#include <stdio.h>
#include <stdlib.h>

// Function to sort the request array using Bubble Sort
void sort(int arr[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Function to implement SCAN Disk Scheduling
void scan(int requests[], int n, int head, int direction, int disk_size) {
    int total_movement = 0;
    int current = head;

    // Sort the requests in ascending order
    sort(requests, n);

    // Find the first request greater than the head position
    int index;
    for (index = 0; index < n; index++) {
        if (requests[index] > head) {
            break;
        }
    }

    printf("Order of servicing requests: ");

    if (direction == 0) { // Move left first
        for (int i = index - 1; i >= 0; i--) {
            printf("%d ", requests[i]);
            total_movement += abs(current - requests[i]);
            current = requests[i];
        }

        // Move to the start of the disk (0)
        total_movement += current;
        current = 0;

        for (int i = index; i < n; i++) {
            printf("%d ", requests[i]);
            total_movement += abs(current - requests[i]);
            current = requests[i];
        }
    } else { // Move right first
        for (int i = index; i < n; i++) {
            printf("%d ", requests[i]);
            total_movement += abs(current - requests[i]);
            current = requests[i];
        }

        // Move to the end of the disk
        total_movement += abs(disk_size - 1 - current);
        current = disk_size - 1;

        for (int i = index - 1; i >= 0; i--) {
            printf("%d ", requests[i]);
            total_movement += abs(current - requests[i]);
            current = requests[i];
        }
    }

    printf("\nTotal head movement: %d\n", total_movement);
}

int main() {
    int n, head, direction, disk_size;

    // Get disk size
    printf("Enter total number of disk blocks: ");
    scanf("%d", &disk_size);

    // Get number of requests
    printf("Enter number of requests: ");
    scanf("%d", &n);

    int requests[n];

    // Get the request sequence
    printf("Enter the request string: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requests[i]);
    }

    // Get starting head position
    printf("Enter starting head position: ");
    scanf("%d", &head);

    // Get direction (0 for Left, 1 for Right)
    printf("Enter direction (0 for Left, 1 for Right): ");
    scanf("%d", &direction);

    // Call SCAN function
    scan(requests, n, head, direction, disk_size);

    return 0;
}
