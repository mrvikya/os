#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARRAY_SIZE 1000

int main(int argc, char *argv[]) {
    int rank, size, i, total_sum = 0;
    int numbers[ARRAY_SIZE], local_sum = 0;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Process 0 initializes the array with random numbers
    if (rank == 0) {
        srand(time(NULL));
        for (i = 0; i < ARRAY_SIZE; i++) {
            numbers[i] = rand() % 100; // Random numbers between 0-99
        }
    }

    int chunk_size = ARRAY_SIZE / size;
    int local_numbers[chunk_size];

    // Scatter the data to all processes
    MPI_Scatter(numbers, chunk_size, MPI_INT, local_numbers, chunk_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Each process calculates its local sum
    for (i = 0; i < chunk_size; i++) {
        local_sum += local_numbers[i];
    }

    // Reduce all local sums to get the total sum at rank 0
    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    // Process 0 prints the total sum
    if (rank == 0) {
        printf("Total sum of 1000 numbers: %d\n", total_sum);
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}
