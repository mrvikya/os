#include <stdio.h>
#include <stdbool.h>

#define P 5  // Number of processes
#define R 4  // Number of resource types

// Function to calculate the Need matrix
void calculateNeed(int need[P][R], int max[P][R], int allocation[P][R]) {
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
        }
    }
}

// Function to check if the system is in a safe state
bool isSafe(int available[], int max[][R], int allocation[][R], int need[][R]) {
    int work[R];
    bool finish[P] = {false}; // Initially, all processes are unfinished

    // Initialize work array with available resources
    for (int i = 0; i < R; i++) {
        work[i] = available[i];
    }

    while (true) {
        bool found = false;

        for (int i = 0; i < P; i++) {
            if (!finish[i]) {  // If process is not finished
                bool canAllocate = true;

                // Check if resources can be allocated
                for (int j = 0; j < R; j++) {
                    if (need[i][j] > work[j]) {
                        canAllocate = false;
                        break;
                    }
                }

                // If resources can be allocated, mark process as finished
                if (canAllocate) {
                    for (int j = 0; j < R; j++) {
                        work[j] += allocation[i][j];
                    }
                    finish[i] = true;
                    found = true;
                    break;
                }
            }
        }

        // If no process was found that could execute, exit the loop
        if (!found) {
            break;
        }
    }

    // Check if all processes are finished
    for (int i = 0; i < P; i++) {
        if (!finish[i]) {
            return false;
        }
    }
    return true;
}

int main() {
    // Allocation Matrix
    int allocation[P][R] = {
        {2, 0, 0, 1},
        {3, 1, 2, 1},
        {2, 1, 0, 3},
        {1, 3, 1, 2},
        {1, 4, 3, 2}
    };

    // Maximum Need Matrix
    int max[P][R] = {
        {4, 2, 1, 2},
        {5, 2, 5, 2},
        {2, 3, 1, 6},
        {1, 4, 2, 4},
        {3, 6, 6, 5}
    };

    // Available Resources
    int available[R] = {3, 3, 2, 1};

    // Need Matrix
    int need[P][R];

    // Calculate Need Matrix
    calculateNeed(need, max, allocation);

    // Check if the system is in a safe state
    if (isSafe(available, max, allocation, need)) {
        printf("The system is in a safe state.\n");
    } else {
        printf("The system is not in a safe state.\n");
    }

    return 0;
}
