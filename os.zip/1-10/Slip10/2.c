#include <stdio.h>
#include <stdlib.h>

// Function to sort disk requests in ascending order
void sortRequests(int requests[], int n) {
    int temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (requests[i] > requests[j]) {
                temp = requests[i];
                requests[i] = requests[j];
                requests[j] = temp;
            }
        }
    }
}

// Function to implement C-SCAN Disk Scheduling
void cscan(int requests[], int n, int head, int total_blocks, int direction) {
    int total_head_movements = 0;
    int served[n];

    // Initialize served array
    for (int i = 0; i < n; i++) {
        served[i] = 0;
    }

    // Sort the requests
    sortRequests(requests, n);

    int left[n], right[n], left_count = 0, right_count = 0;

    // Separate requests into left and right of head
    for (int i = 0; i < n; i++) {
        if (requests[i] < head) {
            left[left_count++] = requests[i];
        } else {
            right[right_count++] = requests[i];
        }
    }

    printf("\nOrder of requests served:\n");

    if (direction == 0) {  // Moving left first
        // Serve left side requests
        for (int i = left_count - 1; i >= 0; i--) {
            total_head_movements += abs(head - left[i]);
            head = left[i];
            printf("%d ", head);
        }

        // Move to the start of the disk (0)
        total_head_movements += abs(head - 0);
        head = 0;
        printf("%d ", head);

        // Jump to the end of the disk
        total_head_movements += abs(total_blocks - 1 - head);
        head = total_blocks - 1;
        printf("%d ", head);

        // Serve right side requests
        for (int i = right_count - 1; i >= 0; i--) {
            total_head_movements += abs(head - right[i]);
            head = right[i];
            printf("%d ", head);
        }

    } else {  // Moving right first
        // Serve right side requests
        for (int i = 0; i < right_count; i++) {
            total_head_movements += abs(head - right[i]);
            head = right[i];
            printf("%d ", head);
        }

        // Move to the end of the disk
        total_head_movements += abs(head - (total_blocks - 1));
        head = total_blocks - 1;
        printf("%d ", head);

        // Jump to the start of the disk
        total_head_movements += abs(head - 0);
        head = 0;
        printf("%d ", head);

        // Serve left side requests
        for (int i = 0; i < left_count; i++) {
            total_head_movements += abs(head - left[i]);
            head = left[i];
            printf("%d ", head);
        }
    }

    // Print total head movements
    printf("\nTotal head movements: %d\n", total_head_movements);
}

int main() {
    int requests[] = {33, 99, 142, 52, 197, 79, 46, 65};
    int n = sizeof(requests) / sizeof(requests[0]);
    int head, direction;

    // Get user input for starting head position
    printf("Enter the starting head position: ");
    scanf("%d", &head);

    // Get direction (0 for left, 1 for right)
    printf("Enter the direction (0 for left, 1 for right): ");
    scanf("%d", &direction);

    // Call C-SCAN function
    cscan(requests, n, head, 200, direction);

    return 0;
}
